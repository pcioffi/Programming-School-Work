/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package searchbooksServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Rino
 */
@WebServlet(name = "searchbooksServlet", urlPatterns = {"/searchbooksServlet"})
public class searchbooksServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet searchbooksServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Live Search List</h1>");
            
            //connect to the database
            String database = "jdbc:mysql://localhost:3306/nyt_books";
            String user = "root";
            String password = "";
            
            Class.forName("com.mysql.jdbc.Driver");
            
            Connection myconn = DriverManager.getConnection(database, user, password);
            
            String searchText = request.getParameter("searchkey");
            String SQLselect = "SELECT * FROM bestsellers_list WHERE " + 
                               "weekending LIKE '%" + searchText + "%' || " +
                               "title LIKE '%" + searchText + "%' || " + 
                               "author LIKE '%" + searchText + "%'";
            Statement mystat = myconn.createStatement();
            
            ResultSet results = mystat.executeQuery(SQLselect);
            
            if(!results.wasNull()){
                out.println("<table border='1'>");
                out.println("<tr><th>Week Ending</th><th>Title</th><th>Author</th></tr>");

                while(results.next()){
                    String endWeek = results.getString("weekending");
                    String intitle = results.getString("title");
                    String inauthor = results.getString("author");

                    out.println("<tr><td>" + endWeek + "</td><td>" + intitle + "</td><td>" + inauthor + "</td></tr>");
                }
                
                out.println("</table>");
            }
            else
                out.println("No records found");
            out.println("</body>");
            out.println("</html>");
        }
        catch(Exception e){}
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
