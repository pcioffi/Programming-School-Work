import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/Hwk6Servlet"})
public class Hwk6Servlet extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Order: Quantity & Discounts</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>'Create WebApp' The Game: Order</h1>");
            
            int unitPrice = 20;             
            double pay = 0.;             
            double fivetoten = 0.2;             
            double tentofifteen = 0.3;             
            double fifteentotwenty = 0.4;             
            double discount = 0.;                  
            
            //getting the passing variables             
            int inputQty = Integer.parseInt(request.getParameter("qtyList"));                  
            
            if (inputQty >= 5 && inputQty <= 10)                 
                discount = unitPrice * inputQty * fivetoten;             
            else if (inputQty > 10 && inputQty <= 15)                 
                discount = unitPrice * inputQty * tentofifteen;             
            else if (inputQty > 15 && inputQty <= 20)                 
                discount = unitPrice * inputQty * fifteentotwenty;                  
            
            pay = unitPrice * inputQty - discount;                    
            
            out.println("Unit Price: " + unitPrice);             
            out.println("<br/>Quantity: " + inputQty); 
            out.println("<br/>Discount: " + discount);
            out.println("<br/>Total Cost: " + pay);
            
            out.println("</body>");
            out.println("</html>");
        }
        catch (Exception e) {}
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
