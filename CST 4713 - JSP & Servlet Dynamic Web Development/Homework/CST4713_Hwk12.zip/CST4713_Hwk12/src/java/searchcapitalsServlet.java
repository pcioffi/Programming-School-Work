import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Rino
 */
@WebServlet(name = "searchcapitalsServlet", urlPatterns = {"/searchcapitalsServlet"})
public class searchcapitalsServlet extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String inputCapital = request.getParameter("dropdown");
            
            //connect to database
            String database = "jdbc:mysql://localhost:3306/capitals";
            String user = "root";
            String password = "";
            
            Class.forName("com.mysql.jdbc.Driver");
            
            Connection myconn = DriverManager.getConnection(database, user, password);
            
            String SQLSelect = "SELECT * FROM capitallist " +
                               "WHERE capital = '" + inputCapital + "'";
            
            Statement mystat = myconn.createStatement();
            
            ResultSet results = mystat.executeQuery(SQLSelect);
            
            if(!results.wasNull()){
                results.next();
                
                String country = results.getString("country");
                String capital = results.getString("capital");
                int miles = results.getInt("miles");
                int kilometers = results.getInt("kilometers");
                DecimalFormat formatter = new DecimalFormat("#,###");

                String output = "<h3>NYC is " + formatter.format(miles) + "mi (" + formatter.format(kilometers) + "km) away from " + capital + ", " + country + "</h3>";
                
                out.println(output);
            }
            else
                out.println("No records found");
        }
        catch(Exception e){}
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
