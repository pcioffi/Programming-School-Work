package cst4713_hwk0;
import java.util.Scanner;

public class CST4713_Hwk0 {
    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        
        Scanner s = new Scanner(System.in);
        System.out.println("Calculate Factorial of Input:");
        int input = s.nextInt();
        
        int n = input;
        int result = 1;
        for (int i = 1; i <= n; i++) {
            result = result * i;
        }
        System.out.println("Results: " + result);
        
        long endTime = System.currentTimeMillis();
        long totalTime = endTime - startTime;
        System.out.println("Total Time For Run: " + totalTime + " Milliseconds");
    }
}
