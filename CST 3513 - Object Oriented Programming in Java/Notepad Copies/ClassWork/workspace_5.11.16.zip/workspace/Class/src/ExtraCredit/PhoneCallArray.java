package ExtraCredit;

public class PhoneCallArray {
	public static void main(String[] args){
		PhoneCall[] phoneArray = new PhoneCall[10];
		
		phoneArray[0] = new IncomingPhoneCall("345-094-8372");
		phoneArray[1] = new OutgoingPhoneCall("644-564-8572", 4);
		phoneArray[2] = new IncomingPhoneCall("343-194-3372");
		phoneArray[3] = new OutgoingPhoneCall("655-999-6372", 10);
		phoneArray[4] = new IncomingPhoneCall("545-065-2362");
		phoneArray[5] = new OutgoingPhoneCall("655-999-6372", 30);
		phoneArray[6] = new IncomingPhoneCall("125-345-4857");
		phoneArray[7] = new OutgoingPhoneCall("235-955-1371", 3);
		phoneArray[8] = new IncomingPhoneCall("644-564-8572");
		phoneArray[9] = new OutgoingPhoneCall("920-787-8919", 5);
		
		for(int i = 0; i < phoneArray.length; i++)
			System.out.println(phoneArray[i].getInformationOfCall());
	}
}
