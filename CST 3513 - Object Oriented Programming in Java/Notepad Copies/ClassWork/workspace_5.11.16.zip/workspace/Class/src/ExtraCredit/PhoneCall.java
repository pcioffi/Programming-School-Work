package ExtraCredit;

public abstract class PhoneCall {
	protected String phoneNumber;
	protected double priceOfCall;
	
	//constructor that sets the price to 0.0
	public PhoneCall(String phoneNumber){
		this.phoneNumber = phoneNumber;
		priceOfCall = 0.0;
	}
	
	//set method of price
	public void setPrice(double price){
		priceOfCall = price;
	}
	
	public abstract String getPhoneNumber();
	public abstract double getPriceOfCall();
	public abstract String getInformationOfCall();
}
