package ExtraCredit;

public class OutgoingPhoneCall extends PhoneCall{
	int timeOfCall;
	
	public OutgoingPhoneCall(String phoneNumber, int timeOfCall){
		super(phoneNumber);
		this.timeOfCall = timeOfCall;
		super.setPrice(0.04);
	}

	public String getPhoneNumber() {
		return super.phoneNumber;
	}

	public double getPriceOfCall() {
		return super.priceOfCall;
	}

	public String getInformationOfCall() {
		double total = getPriceOfCall() * timeOfCall;
		String output = "Outgoing phone call " + getPhoneNumber() + " " +
						getPriceOfCall() + " per minute at " + 
						timeOfCall + " minutes. " +
						"Total is $" + total; 
		return output;
	}
}
