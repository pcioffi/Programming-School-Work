package ExtraCredit;

public class DemoPhoneCalls {
	public static void main(String[] args){
		IncomingPhoneCall incoming = new IncomingPhoneCall("212-555-3096");
		OutgoingPhoneCall outgoing = new OutgoingPhoneCall("312-874-0232", 10);
		
		System.out.println(incoming.getInformationOfCall());
		System.out.println(outgoing.getInformationOfCall());
	}
}
