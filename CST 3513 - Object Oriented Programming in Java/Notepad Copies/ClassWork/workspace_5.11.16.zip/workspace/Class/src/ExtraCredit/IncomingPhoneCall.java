package ExtraCredit;

public class IncomingPhoneCall extends PhoneCall{
	public IncomingPhoneCall(String phoneNumber){
		super(phoneNumber);
		super.setPrice(0.02);
	}

	public String getPhoneNumber() {
		return super.phoneNumber;
	}

	public double getPriceOfCall() {
		return super.priceOfCall;
	}

	public String getInformationOfCall() {
		String output = "Incoming phone call " + getPhoneNumber() + " " +
						getPriceOfCall() + " per call. " +
						"Total is $" + getPriceOfCall();
		return output;
	}
	
	
}
