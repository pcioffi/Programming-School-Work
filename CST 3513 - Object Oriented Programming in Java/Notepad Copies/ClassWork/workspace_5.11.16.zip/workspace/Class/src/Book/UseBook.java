package Book;

public class UseBook {
	public static void main(String[] args){
		//initiating the books
		Fiction ficBook = new Fiction("Frankenstein");
		NonFiction nonFicBook = new NonFiction("Hiroshima");
		
		//printing them out
		System.out.println(ficBook.getTitle() + " is priced at: " + ficBook.getPrice());
		System.out.println(nonFicBook.getTitle() + " is priced at: " + nonFicBook.getPrice());
	}
}