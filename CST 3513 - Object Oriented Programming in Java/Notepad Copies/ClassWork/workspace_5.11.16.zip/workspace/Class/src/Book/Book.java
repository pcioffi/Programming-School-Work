package Book;

public abstract class Book {
	protected String title;
	protected double price;
	
	public Book(String title){
		this.title = title;
	}
	
	//get methods
	public String getTitle(){ return title; }
	public double getPrice(){ return price; }
	
	//abstract setPrice method
	public abstract void setPrice();
}
