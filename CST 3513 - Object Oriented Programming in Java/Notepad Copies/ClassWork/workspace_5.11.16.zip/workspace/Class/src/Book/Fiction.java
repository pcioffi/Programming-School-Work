package Book;

public class Fiction extends Book{
	//constructor
	public Fiction(String title){
		super(title);
		setPrice();
	}
	
	//overridden setPrice method
	public void setPrice() {
		super.price = 24.99;
	}
}