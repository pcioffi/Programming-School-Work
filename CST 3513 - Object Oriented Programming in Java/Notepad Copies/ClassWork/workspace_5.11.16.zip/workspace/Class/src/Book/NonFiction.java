package Book;

public class NonFiction extends Book{
	//constructor
	public NonFiction(String title){
		super(title);
		setPrice();
	}
	
	//overridden setPrice method
	public void setPrice() {
		super.price = 37.99;
	}
}