package ClassWork;

public interface SidedObject {
	void displaySides();
}
