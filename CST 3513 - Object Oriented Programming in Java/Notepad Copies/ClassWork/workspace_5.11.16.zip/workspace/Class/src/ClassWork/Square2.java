package ClassWork;

public class Square2 extends GeometricFigure2 {
	public Square2(int side){
		super(side, side, "Square");
	}

	public double area() {
		return (double) super.height * super.height;
	}

	public void displaySides() {
		System.out.println("This Figure has four sides");
	}
}
