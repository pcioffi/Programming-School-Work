package ClassWork;

public class Triangle extends GeometricFigure{
	public Triangle(int height, int base){
		super(height, base, "Triangle");
	}

	public double area() {
		return (double) (super.height * super.width) / 2;
	}
}
