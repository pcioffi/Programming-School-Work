package ClassWork;

public class Square extends GeometricFigure{
	public Square(int side){
		super(side, side, "Square");
	}

	public double area() {
		return (double) super.height * super.height;
	}
}
