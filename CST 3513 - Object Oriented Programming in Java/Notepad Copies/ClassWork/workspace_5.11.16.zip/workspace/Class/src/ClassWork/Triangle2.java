package ClassWork;

public class Triangle2 extends GeometricFigure2 {
	public Triangle2(int height, int base){
		super(height, base, "Triangle");
	}

	public double area() {
		return (double) (super.height * super.width) / 2;
	}
	
	public void displaySides() {
		System.out.println("This Figure has three sides");
	}
}