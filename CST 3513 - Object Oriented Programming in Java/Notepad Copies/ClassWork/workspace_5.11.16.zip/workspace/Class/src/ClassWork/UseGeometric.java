package ClassWork;

public class UseGeometric {
	public static void main(String[] args){
		GeometricFigure[] geoFig = new GeometricFigure[4];
		
		geoFig[0] = new Square(5);
		geoFig[1] = new Triangle(5, 5);
		geoFig[2] = new Square(10);
		geoFig[3] = new Triangle(10, 10);
		
		for(int i = 0; i < geoFig.length; i++)
			System.out.println("The " + geoFig[i].figureType + 
							   " with height = " + geoFig[i].height +
							   " and with width = " + geoFig[i].width +
							   " has an area of " + geoFig[i].area());
	}
}
