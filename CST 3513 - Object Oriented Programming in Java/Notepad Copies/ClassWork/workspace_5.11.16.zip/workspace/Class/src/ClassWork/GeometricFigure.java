package ClassWork;

public abstract class GeometricFigure {
	protected int height, width;
	protected String figureType;
	protected double area;
	
	public GeometricFigure(int height, int width, String figureType){
		this.height = height;
		this.width = width;
		this.figureType = figureType;
	}
	
	public abstract double area();
}
