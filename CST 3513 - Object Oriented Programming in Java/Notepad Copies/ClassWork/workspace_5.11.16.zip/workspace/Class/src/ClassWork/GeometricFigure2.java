package ClassWork;

public abstract class GeometricFigure2 implements SidedObject{
	protected int height, width;
	protected String figureType;
	protected double area;
	
	public GeometricFigure2(int height, int width, String figureType){
		this.height = height;
		this.width = width;
		this.figureType = figureType;
	}
	
	public abstract double area();

	public abstract void displaySides();
}
