package ClassWork;

public class UseGeometric2 {
	public static void main(String[] args){
		GeometricFigure2[] geoFig = new GeometricFigure2[4];
		
		geoFig[0] = new Square2(5);
		geoFig[1] = new Triangle2(5, 5);
		geoFig[2] = new Square2(10);
		geoFig[3] = new Triangle2(10, 10);
		
		for(int i = 0; i < geoFig.length; i++){
			System.out.println("The " + geoFig[i].figureType + 
							   " with height = " + geoFig[i].height +
							   " and with width = " + geoFig[i].width +
							   " has an area of " + geoFig[i].area());
			geoFig[i].displaySides();
		}
	}
}
