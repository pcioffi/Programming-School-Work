<!DOCTYPE html>
<html>
<!-- fileName: creditlimitreport.php -->
<style>
	.gt100k
	{
		background-color: red;
	}
</style>
<body>
<table>
	<tr>
		<th>lastName</th>
		<th>firstName</th>
		<th>salary</th>
		<th>state</th>
	</tr>
<?php
$servername = "localhost:3306";
$username = "root";
$password = "";
$dbname = "CustomerDB";
$money = 0;

if ( isset($_GET["greaterThan"]) ) {
	$money =  $_GET["greaterThan"];
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 
// salesperson.php?greaterThan=90000
$sql = 
" select lastName, firstName,salary,
 state from SalePerson 
 where salary > $money ";

$result = $conn->query($sql);


function star($pMoney){	
	if ($pMoney > 100000)
		return "*";		
	return "";
}
if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
		 $salary = $row["salary"];
		 $firstName = $row["firstName"];
		 $lastName = $row["lastName"];
		 $state = $row["state"];
		 // conditional operator
		 $bold = $row["salary"] > 100000 ? "gt100k": "";
		 $displayStar = star($row["salary"]);
		 echo " 
			<tr class='$bold'>				
				<td>$lastName</td>
				<td>$firstName</td>
				<td class='countme'>$salary $displayStar</td>				
				<td>$state</td>
			</tr>		 
		 ";        
     }
} else {
     echo "0 results";
}

$conn->close();
?>  
</table>
<script>
	function doSomething(){
	  "use strict";
	  var tds = document.getElementsByClassName("countme");
	  var total = 0;
	  [].forEach.call(tds, function(e,i,a){ 
			total 
				+= parseFloat(e.innerHTML);			
	   });  
	   
	   alert(total);	  
	}

</script>

<input type="button" 
  value="Count Me" onclick="doSomething()" />

</body>
</html>