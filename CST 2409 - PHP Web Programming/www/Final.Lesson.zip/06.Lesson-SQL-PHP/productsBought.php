<!DOCTYPE html>
<html>
<!--- fileName: creditlimitreport.php ------------->
<style>
	table.report{
		border: solid 1px black;			
	}
	
	table.report td, table.report th{
		border: solid 1px black;
		font-family: verdana;
		font-size: 10pt;
		padding-left:2px;
	}	
	
	table.report th{
		background-color:silver;
	}
	
</style>
<body>
<table class="report">
    <tr>
	    <th>Product Name</th>
		<th>Cost</th>
		<th>Quantity</th>
		<th>Purchased</th>
    </tr>



<?php
//Filename: creditlimitreport.php

$servername = "localhost:3306";
$username = "root";
$password = "";
$dbname = "CustomerDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
 } 

$sql = "select p.description, p.cost, o.quantity, 
        p.cost * o.quantity as spent
		from Product p, Orders o
		where p.id = o.productId ";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	$total = 0;
    while($row = $result->fetch_assoc()) {        
		$name = $row["description"];
		$cost = $row["cost"];
		$quantity = $row["quantity"];
		$spent = $row["spent"];
		$spent2 = $row["cost"] * $row["quantity"];
		$total = $total + $spent;
		echo 
		    "<tr>
			    <td>$name</td>
				<td>$cost</td>
				<td>$quantity</td>
				<td>$spent2</td>
		    </tr>";
    }
} else {
    echo "0 results";
}
 $conn->close(); 
 ?> 
	<tfoot>
		<th colspan='3' >Total Spent:</th>
		<th><?php echo $total ?></th>
	</tfoot>
 </table>