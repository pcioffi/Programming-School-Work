
-- fileName: Select.sql
-- display id,lastname,firstname,creditLimit
-- ANSI Standard

select c.id
	  ,c.lastname
	  ,c.firstname
	  ,cl.creditLimit
from Customer c
inner join CreditLimit cl
on  cl.customerId = c.id;


select  sum(p.cost * o.quantity) as spent
		from Product p, Orders o
		where p.id = o.productId