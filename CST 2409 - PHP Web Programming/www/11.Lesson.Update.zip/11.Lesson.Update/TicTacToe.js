// fileName: TicTacToe.js

function TicTacToe(pMoves){
	this.moves = pMoves;
	
	var possibleWinners = [
		{p1:0, p2:1, p3:2},
		{p1:3, p2:4, p3:5},
		{p1:6, p2:7, p3:8},
		
		{p1:0, p2:3, p3:6},
		{p1:1, p2:4, p3:7},
		{p1:2, p2:5, p3:8},
		
		{p1:0, p2:4, p3:8},
		{p1:2, p2:4, p3:6}
	];
	
	var xOrO;
	var whoWon = "";
	var theWinner = {};
	var isWinner = false;
		xOrO = this.moves.split("");
	
	{	
		possibleWinners.every(function(e, i, a){
			if(xOrO[e.p1] == xOrO[e.p2] && xOrO[e.p1] == xOrO[e.p3] && xOrO[e.p1] != "?"){
				whoWon = xOrO[e.p1];
				theWinner = e;
				isWinner = true;
					
				return false;
			}
				
			return true;
		});
	}
	
	this.getWinner = function(){
		return isWinner;
	}
	
	this.getWhoWon = function(){
			return whoWon;
	}
	
	this.getWinningCombo = function(){
		return theWinner;
	}
}